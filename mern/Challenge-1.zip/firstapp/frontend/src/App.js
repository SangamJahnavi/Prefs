import './App.css';
import DisplayComponents from './DisplayComponents';

function App() {
  return (
    <div className="App">
      <h1>This is my React Project Integrated with MongoDB Cluster</h1>
        <DisplayComponents/>
    </div>
  );
}

export default App;
